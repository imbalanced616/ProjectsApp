﻿using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageProjects.xaml
    /// </summary>
    public partial class AddEditPageProjects : Page
    {
        private Projects _currentItem = new Projects();
        public AddEditPageProjects(Projects selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение проекта";
                BtnAdd.Content = "Изменить";
            }
            DataContext = _currentItem;
            CMBProjects.ItemsSource = ProjectBDEntities.GetContext().CustomerCompanies.ToList();
            CMBProjects.SelectedValuePath = "idCustCom";
            CMBProjects.DisplayMemberPath = "Name";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Title))) error.AppendLine("Укажите название проекта.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idCustCom))) error.AppendLine("Укажите компанию заказчика.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Priority))) error.AppendLine("Укажите приоритет выполнения проекта.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.StartDate))) error.AppendLine("Укажите дату начала.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.EndDate))) error.AppendLine("Укажите дату окончания.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (_currentItem.idProject == 0)
            {
                ProjectBDEntities.GetContext().Projects.Add(_currentItem);
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageProjects());
                    MessageBox.Show("Новый проект успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            else
            {
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageProjects());
                    MessageBox.Show("Проект успешно изменён!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageProjects());
        }
    }
}