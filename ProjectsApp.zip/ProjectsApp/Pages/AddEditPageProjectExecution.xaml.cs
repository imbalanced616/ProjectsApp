﻿using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageProjectExecution.xaml
    /// </summary>
    public partial class AddEditPageProjectExecution : Page
    {
        private PTW _currentItem = new PTW();
        public AddEditPageProjectExecution(PTW selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение выполнения проекта";
                BtnAdd.Content = "Изменить";
            }
            DataContext = _currentItem;
            CMBWorker.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
            CMBWorker.SelectedValuePath = "idWorker";
            CMBWorker.DisplayMemberPath = "Surname";

            CMBTask.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
            CMBTask.SelectedValuePath = "idTask";
            CMBTask.DisplayMemberPath = "Title";

            CMBTaskStatuses.ItemsSource = ProjectBDEntities.GetContext().TaskStatuses.ToList();
            CMBTaskStatuses.SelectedValuePath = "idStatus";
            CMBTaskStatuses.DisplayMemberPath = "Name";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            _currentItem.idProject = ClassFrame.selectedProject.idProject;
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idWorker))) error.AppendLine("Укажите фамилию сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idTask))) error.AppendLine("Укажите название задачи.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idTaskStatus))) error.AppendLine("Укажите статус задачи.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (_currentItem.idPTW == 0)
            {
                ProjectBDEntities.GetContext().PTW.Add(_currentItem);
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageProjectExecution(ClassFrame.selectedProject));
                    MessageBox.Show("Новое выполнение проекта успешно добавлено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            else
            {
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageProjectExecution(ClassFrame.selectedProject));
                    MessageBox.Show("Выполнение проекта успешно изменено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageProjectExecution(ClassFrame.selectedProject));
        }
    }
}