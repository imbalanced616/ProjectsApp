﻿using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePositions.xaml
    /// </summary>
    public partial class PagePositions : Page
    {
        public PagePositions()
        {
            InitializeComponent();
            dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(0.8, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(0, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbPos_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgPositions.ItemsSource != null) dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.Where(x => x.Title.ToLower().Contains(txbPos.Text.ToLower())).ToList();
            if (txbPos.Text.Count() == 0) dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }
        private void MenuAddItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPagePositions(null));
        }

        private void MenuEditItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPagePositions((Positions)dtgPositions.SelectedItem));
        }

        private void MenuUpdateItem_Click(object sender, RoutedEventArgs e)
        {
            dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }

        private void MenuDelItem_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgPositions.SelectedItems.Cast<Positions>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ProjectBDEntities.GetContext().Positions.RemoveRange(rowsForRemoving);
                    ProjectBDEntities.GetContext().SaveChanges();
                    dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
                    txtCountRows.Text = dtgPositions.Items.Count.ToString();
                    MessageBox.Show("Данные удалены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.OrderBy(x => x.Title).ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.OrderByDescending(x => x.Title).ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgPositions.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
            txtCountRows.Text = dtgPositions.Items.Count.ToString();
        }
    }
}
