﻿using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageTasks.xaml
    /// </summary>
    public partial class AddEditPageTasks : Page
    {
        private Tasks _currentItem = new Tasks();
        public AddEditPageTasks(Tasks selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение задачи";
                BtnAdd.Content = "Изменить";
            }
            DataContext = _currentItem;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Title))) error.AppendLine("Укажите название задачи.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Comment))) error.AppendLine("Укажите комментарий задачи.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Priority))) error.AppendLine("Укажите приоритет задачи.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (_currentItem.idTask == 0)
            {
                ProjectBDEntities.GetContext().Tasks.Add(_currentItem);
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageTasks());
                    MessageBox.Show("Новая задача успешно добавлена!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            else
            {
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageTasks());
                    MessageBox.Show("Задача успешно изменена!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageTasks());
        }
    }
}
