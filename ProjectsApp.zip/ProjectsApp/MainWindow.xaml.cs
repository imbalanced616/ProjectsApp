﻿using ProjectsApp.Classes;
using System.Windows;

namespace ProjectsApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassFrame.frmObj = FrameWindow;
        }

        private void btnToProjects_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.PageProjects());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToWorkers_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.PageWorkers());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToPositions_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.PagePositions());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToTasks_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.PageTasks());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToCustomerCompanies_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Pages.PageCustomerCompanies());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(null);
            MainMenu.Visibility = Visibility.Visible;
            btnToBack.Visibility = Visibility.Hidden;
            MainImage.Visibility = Visibility.Visible;
        }
    }
}
